﻿//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------------------
using System;
using System.Runtime.Serialization;

namespace TeamTask.Model
{
    public class Task
    {
        [IgnoreDataMember]
        public byte[] Version { get; set; }

        [IgnoreDataMember]
        public User Owner { get; set; }

        // Surfaced below as a TaskStatus Enum
        [IgnoreDataMember]
        public int TaskStatusCode { get; set; }

        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? CompletedOn { get; set; }
        public string OwnerUserName { get; set; }

        public TaskStatus Status
        {
            get
            {
                return (TaskStatus)this.TaskStatusCode;
            }
            set
            {
                this.TaskStatusCode = (int)value;
            }
        }
    }
}
