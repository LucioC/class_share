﻿//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;
using TeamTask.Model;

namespace TeamTask.Service
{
    [ServiceContract]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class TeamTaskService
    {
        [WebGet(UriTemplate = "Tasks?skip={skip}&top={top}&owner={userName}")]
        public List<Task> GetTasks(int skip, int top, string userName)
        {
            // Set reasonable defaults for the query string parameters
            skip = (skip >= 0) ? skip : 0;
            top = (top > 0) ? top : 25;

            using (TeamTaskObjectContext objectContext = new TeamTaskObjectContext())
            {
                // Include the where clause only if a userName was provided
                var taskQuery = (string.IsNullOrWhiteSpace(userName)) ?
                    objectContext.Tasks :
                    objectContext.Tasks.Where(task => task.OwnerUserName == userName);

                return taskQuery.OrderBy(task => task.Id).Skip(skip).Take(top).ToList();
            }
        }

        [WebGet(UriTemplate = "Users/{userName}")]
        public User GetUser(string userName)
        {
            using (TeamTaskObjectContext objectContext = new TeamTaskObjectContext())
            {
                // The 'Include' method is an ADO.NET Entity Framework feature that allows 
                //  us to load the user and his/her tasks in a single query!
                var user = objectContext.Users.Include("Tasks").FirstOrDefault(u => u.UserName == userName);
                return user;
            }
        }
    }
}
