﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.ServiceReference1;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Service1Client proxy = new Service1Client();
            Console.WriteLine(proxy.GetData(0));
            Console.WriteLine(proxy.GetData(1));
            Console.WriteLine(proxy.GetData(2));
            Console.WriteLine(proxy.GetData(3));
            proxy.Close();

            Service1Client proxy2 = new Service1Client();
            Console.WriteLine(proxy2.GetData(0));
            Console.WriteLine(proxy2.GetData(1));
            Console.WriteLine(proxy2.GetData(2));
            Console.WriteLine(proxy2.GetData(3));
        }
    }
}
