﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using Microsoft.Samples.DPE.OAuth.Tokens;
using Microsoft.IdentityModel.Claims;

namespace WebApp
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string rawToken = string.Empty;

            ClaimsIdentity idntity = HttpContext.Current.User.Identity as ClaimsIdentity;
            if (null != idntity)
            {
                SimpleWebToken token = idntity.BootstrapToken as SimpleWebToken;
                if (null != token)
                {
                    rawToken = token.RawToken;
                }
            }


            WebClient client = new WebClient();

            string headerValue = string.Format("WRAP access_token=\"{0}\"", rawToken);

            client.Headers.Add("Authorization", headerValue);


            Stream stream = client.OpenRead(@"http://localhost:40000/RESTfulWCFUsersServiceEndPoint.svc/users");

            StreamReader reader = new StreamReader(stream);
            String response = HttpUtility.HtmlEncode( reader.ReadToEnd());

            Label2.Text = response;
        }

        protected void Page_Prerender(object sender, EventArgs e)
        {
            Label1.Text = HttpContext.Current.User.Identity.Name;

        }

    }
}