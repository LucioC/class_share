﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;

namespace RESTfulWCFLibrary
{
    public class UserService : IUserService
    {
        static Users _users = new Users();
        public Users GetAllUsers()
        {
            //IN YOUR CASE YOU'D PROBABLY ACCESS A DB
            //OR A WEB SERVICE TO RETRIEVE ACTUAL DATA
            GenerateFakeUsers();
            return _users;
        }
        public User AddNewUser(User u)
        {
            u.UserId = Guid.NewGuid().ToString();
            //IN YOUR CASE YOU'D PROBABLY ACCESS A DB
            //OR A WEB SERVICE TO SAVE ACTUAL DATA
            _users.Add(u);
            return u;
        }
        public User GetUser(string user_id)
        {
            var u = FindUser(user_id);
            return u;
        }
        private User FindUser(string user_id)
        {
            //IN YOUR CASE YOU'D PROBABLY ACCESS A DB
            //OR A WEB SERVICE TO RETRIEVE ACTUAL DATA
            return new User()
            {
                FirstName = "FirstName1",
                LastName = "LastName1",
                Email = "email1@demoDomain.com",
                UserId = "1"
            };
        }
        private void GenerateFakeUsers()
        {
            _users.Add(new User()
            {
                FirstName = "FirstName1",
                LastName = "LastName1",
                Email = "email1@demoDomain.com",
                UserId = "1"
            });
            _users.Add(new User()
            {
                FirstName = "FirstName2",
                LastName = "LastName2",
                Email = "email2@demoDomain.com",
                UserId = "2"
            });
        }
    }
}